"""
repl.py - Backward-compatible facade for ultron.repl package.
"""
from ultron.repl.core import UltronREPL, UltronCompleter, main

__all__ = ["UltronREPL", "UltronCompleter", "main"]
